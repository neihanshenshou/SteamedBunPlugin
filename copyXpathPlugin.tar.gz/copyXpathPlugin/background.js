// background.js
let isPluginActive = false;

// 监听插件图标点击事件
chrome.action.onClicked.addListener(async (tab) => {
    isPluginActive = !isPluginActive;
    updateIcon();

    try {
        // 确保内容脚本已注入
        await chrome.scripting.executeScript({
            target: {tabId: tab.id},
            files: ['content.js']
        });

        // 发送插件状态变更消息
        chrome.tabs.sendMessage(tab.id, {
            action: 'pluginStateChanged',
            active: isPluginActive
        });
    } catch (error) {
        console.error('发送消息失败:', error);
    }
});

// 更新插件图标状态
function updateIcon() {
    const path = isPluginActive ?
        {
            16: 'img_1.png',
            48: 'img_1.png',
            128: 'img_1.png'
        } :
        {
            16: 'img.png',
            48: 'img.png',
            128: 'img.png'
        };

    chrome.action.setIcon({path});
    chrome.action.setTitle({title: isPluginActive ? '插件已激活' : '插件未激活'});
}

// 处理来自内容脚本的状态请求
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === 'getPluginState') {
        sendResponse({active: isPluginActive});
    }
});