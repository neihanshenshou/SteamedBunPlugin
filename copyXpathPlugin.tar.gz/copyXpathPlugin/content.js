(function () {
    // 插件状态
    let pluginActive = false;
    let copyMode = 'xpath'; // xpath, smart-xpath, css

    // 功能选择元素
    let modeSelect = null;
    let highlightOverlay = null;

    // 临时提示元素
    let copyTooltip = null;

    // 事件监听器引用
    let clickListener = null;
    let mouseMoveListener = null;

    // 存储键名
    const STORAGE_KEY = 'copyPathAssistantState';

    // 初始化功能选择
    function initModeSelect() {
        // 移除现有选择器
        if (modeSelect && document.body.contains(modeSelect)) {
            modeSelect.remove();
        }

        // 创建选择器容器
        const container = document.createElement('div');
        container.id = 'copy-path-assistant-control';
        container.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 99999;
            display: flex;
            align-items: center;
            background-color: white;
            padding: 8px 12px;
            border-radius: 4px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
        `;

        // 创建标签
        const label = document.createElement('span');
        label.textContent = '路径复制模式:';
        label.style.marginRight = '8px';
        label.style.fontSize = '13px';

        // 创建模式选择下拉菜单
        modeSelect = document.createElement('select');
        modeSelect.id = 'copy-path-mode-select';
        modeSelect.style.cssText = `
            margin-left: 10px;
            padding: 4px 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
            background-color: white;
            font-size: 13px;
            outline: none;
            cursor: pointer;
        `;

        const xpathOption = document.createElement('option');
        xpathOption.value = 'xpath';
        xpathOption.textContent = 'XPath';
        xpathOption.selected = copyMode === 'xpath';

        const smartXpathOption = document.createElement('option');
        smartXpathOption.value = 'smart-xpath';
        smartXpathOption.textContent = '智能XPath';
        smartXpathOption.selected = copyMode === 'smart-xpath';

        const cssOption = document.createElement('option');
        cssOption.value = 'css';
        cssOption.textContent = 'CSS选择器';
        cssOption.selected = copyMode === 'css';

        modeSelect.appendChild(xpathOption);
        modeSelect.appendChild(smartXpathOption);
        modeSelect.appendChild(cssOption);

        // 监听模式变化
        modeSelect.addEventListener('change', function () {
            copyMode = this.value;
            saveState(); // 保存状态
        });

        // 添加到容器
        container.appendChild(label);
        container.appendChild(modeSelect);

        // 添加到页面
        document.body.appendChild(container);
    }

    // 创建高亮覆盖层
    function createHighlightOverlay() {
        if (highlightOverlay) {
            highlightOverlay.remove();
        }

        highlightOverlay = document.createElement('div');
        highlightOverlay.id = 'copy-path-highlight';
        highlightOverlay.style.cssText = `
            position: absolute;
            z-index: 99998;
            pointer-events: none;
            background-color: rgba(33, 150, 243, 0.3);
            border: 2px solid #2196F3;
            transition: all 0.1s ease;
        `;
        document.body.appendChild(highlightOverlay);
    }

    // 更新高亮覆盖层位置
    function updateHighlight(element) {
        if (!highlightOverlay) {
            createHighlightOverlay();
        }

        const rect = element.getBoundingClientRect();
        highlightOverlay.style.left = `${rect.left + window.scrollX}px`;
        highlightOverlay.style.top = `${rect.top + window.scrollY}px`;
        highlightOverlay.style.width = `${rect.width}px`;
        highlightOverlay.style.height = `${rect.height}px`;
    }

    // 创建事件监听器
    function createClickListener() {
        return (event) => {
            if (!pluginActive) return;

            const control = document.getElementById('copy-path-assistant-control');
            if (control && control.contains(event.target)) {
                return;
            }

            const element = event.target;
            event.stopPropagation();
            copyElementPath(element);
        };
    }

    // 创建鼠标移动监听器
    function createMouseMoveListener() {
        return (event) => {
            if (!pluginActive) return;

            const control = document.getElementById('copy-path-assistant-control');
            if (control && control.contains(event.target)) {
                if (highlightOverlay) {
                    highlightOverlay.style.display = 'none';
                }
                return;
            }

            if (highlightOverlay) {
                highlightOverlay.style.display = 'block';
            }

            const element = event.target;
            updateHighlight(element);
        };
    }

    // 复制元素路径（XPath或CSS选择器）
    function copyElementPath(element) {
        let path = '';
        let feedbackText = '';

        switch (copyMode) {
            case 'xpath':
                path = getXPath(element);
                feedbackText = `已复制 ${element.tagName.toLowerCase()} 的XPath`;
                break;

            case 'smart-xpath':
                path = getSmartXPath(element);
                feedbackText = `已复制 ${element.tagName.toLowerCase()} 的智能XPath`;
                break;

            case 'css':
                path = getCSSSelector(element);
                feedbackText = `已复制 ${element.tagName.toLowerCase()} 的CSS选择器`;
                break;
        }

        if (!path) return;

        copyPathAndShowFeedback(path, feedbackText, element);
    }

    // 获取元素的XPath（按优先级生成）
    function getXPath(element) {
        if (!element || element === document) return '/html';

        // 按优先级顺序尝试生成XPath
        const xpathByPriority = [
            tryGetIdXPath,
            tryGetNameXPath,
            tryGetPlaceholderXPath,
            tryGetAltXPath,
            tryGetHtXPath,
            tryGetTextXPath,
            tryGetTitleXPath,
            tryGetTypeXPath,
            tryGetDataAttrXPath,
            getAbsoluteXPath
        ];

        for (const generator of xpathByPriority) {
            const xpath = generator.call(this, element);
            if (xpath) return xpath;
        }

        return '/html';
    }

    // 获取智能XPath（结合多种定位策略）
    function getSmartXPath(element) {
        if (!element || element === document) return '/html';

        // 优先使用ID
        if (element.id) {
            return `//${element.tagName.toLowerCase()}[@id='${escapeXPathValue(element.id)}']`;
        }

        // 特殊元素处理
        if (element.tagName === 'INPUT') {
            return getInputXPath(element);
        } else if (element.tagName === 'SELECT') {
            return getSelectXPath(element);
        } else if (element.tagName === 'OPTION') {
            return getOptionXPath(element);
        } else if (element.tagName === 'A') {
            return getAnchorXPath(element);
        }

        // 按优先级生成XPath
        return getXPath(element);
    }

    // 按优先级顺序的XPath生成函数
    function tryGetIdXPath(element) {
        if (element.id) {
            return `//${element.tagName.toLowerCase()}[@id='${escapeXPathValue(element.id)}']`;
        }
        return null;
    }

    function tryGetNameXPath(element) {
        if (element.hasAttribute('name') && element.getAttribute('name')) {
            return `//${element.tagName.toLowerCase()}[@name='${escapeXPathValue(element.getAttribute('name'))}']`;
        }
        return null;
    }

    function tryGetPlaceholderXPath(element) {
        if (element.hasAttribute('placeholder') && element.getAttribute('placeholder')) {
            return `//${element.tagName.toLowerCase()}[@placeholder='${escapeXPathValue(element.getAttribute('placeholder'))}']`;
        }
        return null;
    }

    function tryGetAltXPath(element) {
        if (element.hasAttribute('alt') && element.getAttribute('alt')) {
            return `//${element.tagName.toLowerCase()}[@alt='${escapeXPathValue(element.getAttribute('alt'))}']`;
        }
        return null;
    }

    function tryGetHtXPath(element) {
        // 假设ht是自定义属性，可根据实际需求调整
        if (element.hasAttribute('ht') && element.getAttribute('ht')) {
            return `//${element.tagName.toLowerCase()}[@ht='${escapeXPathValue(element.getAttribute('ht'))}']`;
        }
        return null;
    }

    function tryGetTextXPath(element) {
        // 获取包含所有子元素文本的完整内容
        let fullText = getFullTextContent(element).trim();
        if (!fullText) return null;
        fullText = fullText.split("\n")[0]

        // 生成带文本条件的XPath（使用normalize-space处理所有文本）
        const xpath = `//${element.tagName.toLowerCase()}[contains(text(), '${escapeXPathValue(fullText)}')]`;
        if (isUniqueXPath(xpath, element, 1)) {
            return xpath;
        }


        // 尝试更精确的文本匹配
        if (fullText.length >= 2) {
            const exactXPath = `//${element.tagName.toLowerCase()}[text()='${escapeXPathValue(fullText)}']`;
            if (isUniqueXPath(exactXPath, element, 2)) {
                return exactXPath;
            }
        }

        // 尝试使用文本片段匹配（提高唯一性）
        const sampleText = getTextSample(fullText);
        if (sampleText) {
            const sampleXPath = `//${element.tagName.toLowerCase()}[contains(text(), '${escapeXPathValue(sampleText)}')]`;
            if (isUniqueXPath(sampleXPath, element, 3)) {
                return sampleXPath;
            }
        }

        return null;
    }

    // 获取元素及其子元素的完整文本内容
    function getFullTextContent(element) {
        return (element.textContent || element.innerText || '').trim();
    }

    // 生成文本样本（提高唯一性）
    function getTextSample(fullText) {
        if (fullText.length <= 8) return fullText;

        // 优先选择包含特殊字符或数字的部分
        const specialMatch = fullText.match(/[0-9!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?].+?[0-9!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]|.+?[0-9!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]|.[0-9!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?].+?/);
        if (specialMatch && specialMatch[0].length >= 3) {
            return specialMatch[0].trim();
        }

        // 否则取中间1/3文本
        const start = Math.max(0, Math.floor(fullText.length / 4));
        const end = Math.min(fullText.length, Math.floor(fullText.length * 3 / 4));
        return fullText.substring(start, end).trim();
    }

    function tryGetTitleXPath(element) {
        if (element.hasAttribute('title') && element.getAttribute('title')) {
            return `//${element.tagName.toLowerCase()}[@title='${escapeXPathValue(element.getAttribute('title'))}']`;
        }
        return null;
    }

    function tryGetTypeXPath(element) {
        if (element.hasAttribute('type') && element.getAttribute('type')) {
            return `//${element.tagName.toLowerCase()}[@type='${escapeXPathValue(element.getAttribute('type'))}']`;
        }
        return null;
    }

    function tryGetDataAttrXPath(element) {
        // 检查自定义data-属性
        for (let i = 0; i < element.attributes.length; i++) {
            const attr = element.attributes[i];
            if (attr.name.startsWith('data-') && attr.value) {
                return `//${element.tagName.toLowerCase()}[@${attr.name}='${escapeXPathValue(attr.value)}']`;
            }
        }
        return null;
    }

    // 获取绝对路径（最后 fallback）
    function getAbsoluteXPath(element) {
        let path = '';
        let current = element;
        let index = 0;
        let sibling;

        while (current && current !== document) {
            if (current.tagName === 'HTML') {
                path = '/html' + path;
                break;
            }

            index = 1;
            sibling = current.previousSibling;

            while (sibling) {
                if (sibling.tagName === current.tagName) {
                    index++;
                }
                sibling = sibling.previousSibling;
            }

            path = `/${current.tagName.toLowerCase()}[${index}]` + path;
            current = current.parentNode;
        }

        return path;
    }

    // 获取input元素的XPath
    function getInputXPath(element) {
        // 按优先级尝试不同属性
        if (element.id) {
            return `//input[@id='${escapeXPathValue(element.id)}']`;
        }
        if (element.hasAttribute('name')) {
            return `//input[@name='${escapeXPathValue(element.getAttribute('name'))}']`;
        }
        if (element.hasAttribute('ht')) {
            return `//input[@ht='${escapeXPathValue(element.getAttribute('ht'))}']`;
        }
        if (element.hasAttribute('placeholder')) {
            return `//input[@placeholder='${escapeXPathValue(element.getAttribute('placeholder'))}']`;
        }
        if (element.hasAttribute('type')) {
            return `//input[@type='${escapeXPathValue(element.getAttribute('type'))}']`;
        }
        if (element.hasAttribute('value') && element.value.trim()) {
            return `//input[@value='${escapeXPathValue(element.value.trim())}']`;
        }
        return getAbsoluteXPath(element);
    }

    // 获取select元素的XPath
    function getSelectXPath(element) {
        if (element.id) {
            return `//select[@id='${escapeXPathValue(element.id)}']`;
        }
        if (element.hasAttribute('name')) {
            return `//select[@name='${escapeXPathValue(element.getAttribute('name'))}']`;
        }
        // 检查选中的option文本
        const selectedOption = element.querySelector('option:checked');
        if (selectedOption && selectedOption.textContent.trim()) {
            const optionText = selectedOption.textContent.trim();
            return `//select[option[contains(normalize-space(), '${escapeXPathValue(optionText)}')]]`;
        }
        return getAbsoluteXPath(element);
    }

    // 获取option元素的XPath
    function getOptionXPath(element) {
        // 获取父select的定位
        const selectXPath = getSelectXPath(element.parentElement);

        // 添加option的文本定位
        const text = element.textContent.trim();
        return `${selectXPath}/option[contains(normalize-space(), '${escapeXPathValue(text)}')]`;
    }

    // 获取a元素的XPath
    function getAnchorXPath(element) {
        if (element.id) {
            return `//a[@id='${escapeXPathValue(element.id)}']`;
        }
        if (element.hasAttribute('href') && element.getAttribute('href') !== '#') {
            const href = element.getAttribute('href');
            return `//a[@href='${escapeXPathValue(href)}']`;
        }
        const text = element.textContent.trim();
        if (text) {
            return `//a[contains(normalize-space(), '${escapeXPathValue(text)}')]`;
        }
        return getAbsoluteXPath(element);
    }

    // 检查XPath是否唯一匹配当前元素
    function isUniqueXPath(xpath, element, assertLength = 1) {
        try {
            const result = document.evaluate(xpath, document, null, XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null);

            if (result.snapshotLength <= assertLength && element) {
                return true;
            }
        } catch (e) {
            console.error('XPath评估失败:', e);
        }

        return false;
    }

    // 转义XPath中的特殊字符
    function escapeXPathValue(value) {
        return value
            .replace(/'/g, "'\"'\"'")
            .replace(/\n/g, '\\n')
            .replace(/\r/g, '\\r')
            .replace(/\t/g, '\\t');
    }

    // 获取元素的CSS选择器
    function getCSSSelector(element) {
        if (!element || element === document) return '';

        const path = [];
        let current = element;

        while (current && current !== document) {
            const tagName = current.tagName.toLowerCase();
            let selector = tagName;

            // 检查ID选择器
            if (current.id) {
                selector = `#${current.id}`;
                path.unshift(selector);
                break;
            }

            // 检查类选择器（虽然用户要求去除，但保留基础逻辑）
            if (current.className) {
                const classes = current.className.trim().split(' ').filter(c => c);
                if (classes.length) {
                    selector += '.' + classes.join('.');
                }
            }

            // 检查兄弟元素
            let siblingIndex = 0;
            let sibling = current.previousSibling;

            while (sibling) {
                if (sibling.tagName && sibling.tagName.toLowerCase() === tagName) {
                    siblingIndex++;
                }
                sibling = sibling.previousSibling;
            }

            if (siblingIndex > 0) {
                selector += `:nth-of-type(${siblingIndex + 1})`;
            }

            path.unshift(selector);
            current = current.parentNode;

            // 如果是body，停止
            if (current && current.tagName.toLowerCase() === 'body') {
                path.unshift('body');
                break;
            }
        }

        return path.join(' > ');
    }

    // 复制路径并显示反馈
    function copyPathAndShowFeedback(path, feedback, element) {
        if (copyTooltip) {
            copyTooltip.remove();
            copyTooltip = null;
        }

        copyTooltip = document.createElement('div');
        copyTooltip.style.cssText = `
            position: fixed;
            z-index: 99999;
            color: white;
            padding: 8px 12px;
            border-radius: 4px;
            font-size: 14px;
            pointer-events: none;
            opacity: 0;
            transition: opacity 0.3s, transform 0.3s;
            background-color: rgba(76, 175, 80, 0.9);
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            transform: translateY(10px);
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
        `;

        document.body.appendChild(copyTooltip);

        navigator.clipboard.writeText(path)
            .then(() => {
                copyTooltip.textContent = feedback;
            })
            .catch(err => {
                console.error('复制失败:', err);
                copyTooltip.textContent = '复制失败';
                copyTooltip.style.backgroundColor = 'rgba(217, 83, 79, 0.9)';
            })
            .finally(() => {
                const rect = element.getBoundingClientRect();
                copyTooltip.style.left = `${rect.left + window.scrollX}px`;
                copyTooltip.style.top = `${rect.top + window.scrollY - 40}px`;

                setTimeout(() => {
                    copyTooltip.style.opacity = '1';
                    copyTooltip.style.transform = 'translateY(0)';

                    setTimeout(() => {
                        copyTooltip.style.opacity = '0';
                        copyTooltip.style.transform = 'translateY(10px)';

                        setTimeout(() => {
                            if (copyTooltip && document.body.contains(copyTooltip)) {
                                copyTooltip.remove();
                                copyTooltip = null;
                            }
                        }, 300);
                    }, 2000);
                }, 10);
            });
    }

    // 更新事件监听器状态
    function updateEventListener() {
        if (clickListener) {
            document.removeEventListener('click', clickListener);
        }

        if (mouseMoveListener) {
            document.removeEventListener('mousemove', mouseMoveListener);
        }

        if (pluginActive) {
            clickListener = createClickListener();
            document.addEventListener('click', clickListener);

            mouseMoveListener = createMouseMoveListener();
            document.addEventListener('mousemove', mouseMoveListener);
        } else {
            clickListener = null;
            mouseMoveListener = null;
        }
    }

    // 从存储中加载状态
    function loadState() {
        return new Promise(resolve => {
            chrome.storage.sync.get([STORAGE_KEY], (result) => {
                const savedState = result[STORAGE_KEY];
                if (savedState !== undefined) {
                    copyMode = savedState.mode || 'xpath';
                }
                resolve();
            });
        });
    }

    // 保存状态到存储
    function saveState() {
        chrome.storage.sync.set({
            [STORAGE_KEY]: {
                mode: copyMode
            }
        });
    }

    // 更新UI状态
    function updateUI() {
        if (pluginActive) {
            if (!modeSelect || !document.body.contains(modeSelect)) {
                initModeSelect();
            }

            updateEventListener();
        } else {
            if (modeSelect && document.body.contains(modeSelect)) {
                const container = document.getElementById('copy-path-assistant-control');
                if (container) container.remove();
                modeSelect = null;
            }

            if (highlightOverlay) {
                highlightOverlay.remove();
                highlightOverlay = null;
            }

            if (clickListener) {
                document.removeEventListener('click', clickListener);
                clickListener = null;
            }

            if (mouseMoveListener) {
                document.removeEventListener('mousemove', mouseMoveListener);
                mouseMoveListener = null;
            }
        }
    }

    // 监听来自后台脚本的消息
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
        if (message.action === 'pluginStateChanged') {
            pluginActive = message.active;
            updateUI();
        }
    });

    // 初始化 - 先加载状态，再请求插件状态
    async function init() {
        await loadState();

        // 简化消息发送
        chrome.runtime.sendMessage({action: 'getPluginState'}, (response) => {
            if (response) {
                pluginActive = response.active;
                updateUI();
            }
        });
    }

    // 启动初始化
    init();

    // 清理
    window.addEventListener('beforeunload', () => {
        if (clickListener) {
            document.removeEventListener('click', clickListener);
            clickListener = null;
        }

        if (mouseMoveListener) {
            document.removeEventListener('mousemove', mouseMoveListener);
            mouseMoveListener = null;
        }

        if (copyTooltip) {
            copyTooltip.remove();
            copyTooltip = null;
        }

        if (highlightOverlay) {
            highlightOverlay.remove();
            highlightOverlay = null;
        }
    });
})();