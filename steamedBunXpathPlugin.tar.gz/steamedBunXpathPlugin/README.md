# Xpath 生成器 Chrome Extension

Xpath 生成器 is a powerful Chrome extension that helps you generate XPath or Css Selector expressions for any element on a webpage. It's designed to make web scraping, test automation, and web development tasks easier.
![输入图片说明](2025-04-22_212555.jpg)

## Features

- 🔍 Select any element on a webpage with a simple click
- 🌟 Highlight selected elements visually
- 🧩 Generate multiple XPath expressions for each element
- 📋 Copy XPath expressions to clipboard with one click
- 🔄 Focus on generating relative and unique XPath expressions for reliable automation testing
- 🔄 Support for CSS selector generation mode

## Installation

1. Download the extension files or clone this repository
2. Open Chrome and navigate to `chrome://extensions/`
3. Enable "Developer mode" in the top right corner
4. Click "Load unpacked" and select the extension directory
5. The Xpath 生成器 icon should now appear in your Chrome toolbar

## How to Use

1. Click on the Xpath 生成器 icon in your Chrome toolbar
2. Toggle the switch to activate element selection mode
3. Hover over elements on the webpage to see them highlighted
4. Click on an element to generate XPath expressions
5. View the generated XPaths in the popup
6. Click the "Copy" button next to any XPath to copy it to your clipboard
7. Toggle the switch off to deactivate element selection mode

## Modes

### Basic Mode vs Full Mode
- Basic Mode: Shows only optimized XPath expressions
- Full Mode: Shows all categories of XPath expressions

### XPath Mode vs CSS Mode
- XPath Mode: Generates XPath expressions for selected elements
- CSS Mode: Generates CSS selectors for selected elements

## XPath Categories

The extension generates several types of XPath expressions:

- **ID-based**: XPaths using element IDs (most reliable)
- **Attribute-based**: XPaths using element attributes
- **Text-based**: XPaths using element text content
- **Class-based**: XPaths using CSS classes
- **Position-based**: XPaths using element position
- **Optimized**: Best XPaths for automation
- **Absolute**: Full path from the root element

## CSS Selector Categories

The extension generates several types of CSS selectors:

- **ID-based**: Selectors using element IDs (most reliable)
- **Class-based**: Selectors using CSS classes
- **Attribute-based**: Selectors using element attributes
- **Tag-based**: Selectors using element tag names
- **Combinators**: Selectors using parent-child relationships
- **Optimized**: Best CSS selectors for automation
- **Absolute**: Full path from the root element

## Development

### Project Structure

- `manifest.json`: Extension configuration
- `popup.html`: User interface for the extension popup
- `popup.js`: JavaScript for the popup functionality
- `content.js`: Content script that runs on webpages
- `background.js`: Background service worker
- `css_selectors_copy.js`: CSS selector generation functions
- `content.css`: Styles for the element highlighting
- `images/`: Icons for the extension

## Limitations

Xpath 生成器 cannot run on:
- Chrome internal pages (chrome://)
- Extension pages (chrome-extension://)
- PDF files
